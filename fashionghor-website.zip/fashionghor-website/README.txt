FashionGhor — Static Storefront (Demo)
======================================
A standalone static website. No build step, no framework.
Just open index.html in a browser, or upload the whole
"fashionghor-website" folder to any static host
(Netlify, Vercel, GitHub Pages, cPanel, etc.).

Files:
  index.html   - page structure
  style.css    - all styles
  app.js       - all logic (plain JavaScript)
  assets/      - logo.png, prod-01..15.png, banner-01..03.jpg

Features:
  - Hero slider, flash-sale countdown, category + search filter
  - Product quick view (size S/M/L/XL, color, qty), Buy button
  - Cart drawer, wishlist, star reviews (session-only)
  - Checkout with delivery areas:
        Inside Shahbazpur — ৳50
        Inside Brahmanbaria — ৳60
      (free delivery on ৳2000+ orders), coupon WELCOME10 = 10% off
  - "WhatsApp-এ Order করো" button -> opens WhatsApp chat with the
    full order pre-filled as a message
  - Cash on Delivery option, bKash shown as DEMO only
  - Order ID + printable invoice, order tracking (demo statuses)
  - Related products, footer with return/refund policy
  - Admin panel: product add/edit/delete (image upload via FileReader),
    order list + status update, password change — all session-only

How to change the ADMIN PASSWORD:
  Open app.js, find the CONFIG section at the very top, and change:
      ADMIN_PASSWORD: '27575973#'
  to your new password. Save and re-upload.

WhatsApp number (receives orders):
  Currently set to 8801841190116 in CONFIG (WHATSAPP_NUMBER in app.js).
  Change it there if needed.

IMPORTANT — DEMO LIMITS (honest):
  * Admin login is a client-side demo gate, NOT real security.
  * bKash flow is labeled DEMO — no real money moves.
  * Cart/products/orders/reviews added in-session vanish on reload.
  * For PRODUCTION you need the real backend (Node.js + database +
    bKash Tokenized Checkout with server-side verification) and a
    proper server-side admin login with hashed passwords.
