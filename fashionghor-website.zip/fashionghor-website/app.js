/* ============================================================
   FashionGhor — standalone static storefront (no build step)
   ------------------------------------------------------------
   ★ OWNER CONFIG — change these values as needed ★
   ============================================================ */
const CONFIG = {
  // Admin panel password. Change this string to change the password.
  // NOTE (demo-only): this static site has no server, so the password
  // lives in this file and is NOT real security. For production, use
  // the real backend (Node + bcrypt + JWT) with a hashed password.
  ADMIN_PASSWORD: '27575973#',

  // WhatsApp number that receives orders (country code, no +)
  WHATSAPP_NUMBER: '8801841190116',

  // Coupon codes -> discount fraction
  COUPONS: { 'WELCOME10': 0.10 },

  // Delivery areas (exactly the two the owner configured)
  DELIVERY_AREAS: [
    { id: 'shahbazpur',   label: 'Inside Shahbazpur',   charge: 50 },
    { id: 'brahmanbaria', label: 'Inside Brahmanbaria', charge: 60 }
  ],

  // Free delivery threshold (announcement bar promise)
  FREE_DELIVERY_MIN: 2000
};
// Session-overridable admin password (Password Change tab updates this only)
let adminPassword = CONFIG.ADMIN_PASSWORD;

/* ---------------- Product catalog (15) ---------------- */
const CATS = { tshirt:'T-Shirt', dress:'Dress', pant:'Pant', sunglass:'Sunglass', watch:'Watch' };
const SIZED_CATS = ['tshirt','dress','pant'];
const SIZES = ['S','M','L','XL'];

const PRODUCTS = [
  {id:1, name:'Premium Black Cotton Tee', cat:'tshirt', price:590, old:790, img:'assets/prod-01.png', rating:4.5, colors:['Black','White','Navy'], desc:'100% premium cotton, comfortable regular fit. Perfect for daily wear.', reviews:[{n:'Arif',r:5,t:'কাপড়টা অনেক ভালো, ফিটিং perfect!'}]},
  {id:2, name:'Classic White Crew Tee', cat:'tshirt', price:450, old:0, img:'assets/prod-02.png', rating:4.2, colors:['White','Grey'], desc:'Everyday essential white tee. Soft, breathable, easy to wash.', reviews:[{n:'Sakib',r:4,t:'ভালো quality, দাম অনুযায়ী best.'}]},
  {id:3, name:'Graphic Street Tee', cat:'tshirt', price:650, old:850, img:'assets/prod-03.png', rating:4.7, colors:['Black','Olive'], desc:'Trendy streetwear graphic tee with premium print that lasts.', reviews:[{n:'Naim',r:5,t:'Design টা জোস! Print ওঠে না।'}]},
  {id:4, name:'Floral Summer Dress', cat:'dress', price:1290, old:1690, img:'assets/prod-04.png', rating:4.8, colors:['Floral Pink','Floral Blue'], desc:'Light floral summer dress — breezy, elegant, perfect for daytime outings.', reviews:[{n:'Mim',r:5,t:'খুব সুন্দর, ছবির মতোই এসেছে।'}]},
  {id:5, name:'Elegant Evening Gown', cat:'dress', price:2490, old:0, img:'assets/prod-05.png', rating:4.9, colors:['Maroon','Black'], desc:'Stunning evening gown for parties and special occasions.', reviews:[{n:'Tania',r:5,t:'Party তে সবাই জিজ্ঞেস করেছে কোথা থেকে কিনেছি!'}]},
  {id:6, name:'Casual Denim Dress', cat:'dress', price:1090, old:0, img:'assets/prod-06.png', rating:4.4, colors:['Light Denim','Dark Denim'], desc:'Comfortable casual denim dress — stylish for college and hangouts.', reviews:[{n:'Ritu',r:4,t:'Fit ভালো, denim quality solid.'}]},
  {id:7, name:'Slim-Fit Chino Pants', cat:'pant', price:990, old:0, img:'assets/prod-07.png', rating:4.3, colors:['Beige','Khaki','Navy'], desc:'Smart slim-fit chinos — office to outing, always sharp.', reviews:[{n:'Fahim',r:4,t:'Office এর জন্য perfect.'}]},
  {id:8, name:'Classic Blue Denim Jeans', cat:'pant', price:1190, old:1490, img:'assets/prod-08.png', rating:4.6, colors:['Blue','Black'], desc:'Timeless blue denim jeans with durable stitching and comfort stretch.', reviews:[{n:'Rakib',r:5,t:'Jeans টা heavy quality, satisfied.'}]},
  {id:9, name:'Comfort Jogger Pants', cat:'pant', price:790, old:0, img:'assets/prod-09.png', rating:4.5, colors:['Grey','Black'], desc:'Super-comfy joggers for gym, travel and lazy days.', reviews:[{n:'Tanvir',r:5,t:'অনেক আরামদায়ক, gym এর জন্য নিয়েছি।'}]},
  {id:10, name:'Aviator Classic Sunglasses', cat:'sunglass', price:890, old:0, img:'assets/prod-10.png', rating:4.4, colors:['Gold','Silver'], desc:'Timeless aviator frame with UV400 protection.', reviews:[{n:'Shuvo',r:4,t:'Look premium, UV protection আছে।'}]},
  {id:11, name:'Tortoiseshell Wayfarer', cat:'sunglass', price:1050, old:1290, img:'assets/prod-11.png', rating:4.7, colors:['Tortoise','Black'], desc:'Iconic wayfarer in tortoiseshell finish — suits every face.', reviews:[{n:'Hasan',r:5,t:'Style টা দারুণ, gift দিয়েছি।'}]},
  {id:12, name:'Retro Round Sunglasses', cat:'sunglass', price:750, old:0, img:'assets/prod-12.png', rating:4.2, colors:['Gold-Black','Silver-Blue'], desc:'Vintage-inspired round frames with a modern twist.', reviews:[{n:'Emon',r:4,t:'Retro look পছন্দ হলে নিন।'}]},
  {id:13, name:'Minimal Leather Strap Watch', cat:'watch', price:1990, old:2490, img:'assets/prod-13.png', rating:4.8, colors:['Brown','Black'], desc:'Minimal dial, genuine leather strap — classy for every occasion.', reviews:[{n:'Rafi',r:5,t:'Watch টা হাতে premium লাগে!'}]},
  {id:14, name:'Sport Chronograph Watch', cat:'watch', price:2290, old:0, img:'assets/prod-14.png', rating:4.6, colors:['Black-Red','Blue'], desc:'Bold sport chronograph — water resistant, built to last.', reviews:[{n:'Jahid',r:5,t:'Sporty look, battery backup ভালো।'}]},
  {id:15, name:'Classic Steel Bracelet Watch', cat:'watch', price:2790, old:0, img:'assets/prod-15.png', rating:4.9, colors:['Silver','Gold'], desc:'Premium stainless steel watch — the ultimate everyday luxury.', reviews:[{n:'Kamal',r:5,t:'Gift হিসেবে দিয়েছি, সবাই impressed!'}]}
];

/* ---------------- Session state ---------------- */
let cart = [];            // {pid,size,color,qty}
let wishlist = new Set(); // product ids
let orders = [];          // placed orders (session only)
let coupon = null;        // applied coupon code
let filter = { cat:'all', q:'' };

/* ---------------- Helpers ---------------- */
const $ = id => document.getElementById(id);
const fmt = n => '৳' + Math.round(n).toLocaleString('en-US');
const findP = id => PRODUCTS.find(p => p.id === id);
function stars(r){
  let s = '';
  for(let i=1;i<=5;i++) s += i <= Math.round(r) ? '★' : '☆';
  return '<span class="stars" title="'+r+'">'+s+'</span>';
}
function toast(msg){
  const t = $('toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(t._h); t._h = setTimeout(()=>t.classList.remove('show'), 2200);
}
function openModal(id){ $(id).classList.add('open'); $(id).setAttribute('aria-hidden','false'); document.body.style.overflow='hidden'; }
function closeModal(id){ $(id).classList.remove('open'); $(id).setAttribute('aria-hidden','true'); document.body.style.overflow=''; }
document.addEventListener('click', e=>{
  const c = e.target.closest('[data-close]');
  if(c) closeModal(c.getAttribute('data-close'));
});
document.addEventListener('keydown', e=>{
  if(e.key === 'Escape') document.querySelectorAll('.modal.open').forEach(m=>closeModal(m.id));
});
function discountPct(p){ return p.old > p.price ? Math.round((1 - p.price/p.old)*100) : 0; }

/* ---------------- Hero slider ---------------- */
const SLIDES = [
  {img:'assets/banner-01.jpg', h:'⚡ Flash Sale!', p:'সেরা fashion deal — সীমিত সময়ের জন্য'},
  {img:'assets/banner-02.jpg', h:'🆕 New Arrival', p:'নতুন collection এখন FashionGhor-এ'},
  {img:'assets/banner-03.jpg', h:'🎁 Festive Offer', p:'উৎসবের সেরা উপহার — coupon WELCOME10'}
];
let heroIdx = 0, heroTimer = null;
function renderSlides(){
  $('slides').innerHTML = SLIDES.map((s,i)=>
    '<div class="slide'+(i===0?' active':'')+'"><img src="'+s.img+'" alt="'+s.h+'"><div class="slide-cap"><h2>'+s.h+'</h2><p>'+s.p+'</p></div></div>'
  ).join('');
  $('heroDots').innerHTML = SLIDES.map((_,i)=>'<span data-i="'+i+'" class="'+(i===0?'active':'')+'"></span>').join('');
  $('heroDots').querySelectorAll('span').forEach(d=>d.addEventListener('click',()=>goSlide(+d.dataset.i)));
}
function goSlide(i){
  heroIdx = (i + SLIDES.length) % SLIDES.length;
  document.querySelectorAll('.slide').forEach((s,k)=>s.classList.toggle('active', k===heroIdx));
  document.querySelectorAll('#heroDots span').forEach((d,k)=>d.classList.toggle('active', k===heroIdx));
}
function startHero(){ heroTimer = setInterval(()=>goSlide(heroIdx+1), 5000); }

/* ---------------- Flash countdown (to midnight) ---------------- */
function tickCountdown(){
  const now = new Date(), end = new Date(now); end.setHours(23,59,59,999);
  let s = Math.max(0, Math.floor((end-now)/1000));
  const h = String(Math.floor(s/3600)).padStart(2,'0'),
        m = String(Math.floor(s%3600/60)).padStart(2,'0'),
        sec = String(s%60).padStart(2,'0');
  $('countdown').textContent = h+':'+m+':'+sec;
}

/* ---------------- Product grid ---------------- */
function filteredProducts(){
  return PRODUCTS.filter(p=>{
    const okCat = filter.cat==='all' || p.cat===filter.cat;
    const okQ = !filter.q || (p.name+' '+CATS[p.cat]).toLowerCase().includes(filter.q.toLowerCase());
    return okCat && okQ;
  });
}
function renderProducts(){
  const list = filteredProducts();
  $('gridEmpty').hidden = list.length > 0;
  $('gridTitle').textContent = filter.cat==='all' ? 'সব Product' : CATS[filter.cat];
  $('productGrid').innerHTML = list.map(p=>{
    const pct = discountPct(p);
    const inW = wishlist.has(p.id);
    return '<div class="card">'+
      (pct?'<span class="off-badge">-'+pct+'%</span>':'')+
      '<img class="pimg" src="'+p.img+'" alt="'+p.name+'" data-qv="'+p.id+'">'+
      '<div class="card-body">'+
        '<div class="card-name" data-qv="'+p.id+'">'+p.name+'</div>'+
        stars(p.rating)+
        '<div><span class="price">'+fmt(p.price)+'</span>'+(p.old?'<span class="old-price">'+fmt(p.old)+'</span>':'')+'</div>'+
        '<div class="card-actions">'+
          '<button class="btn btn-buy" data-buy="'+p.id+'">Buy</button>'+
          '<button class="btn-wish'+(inW?' active':'')+'" data-wish="'+p.id+'" title="Wishlist">❤️</button>'+
        '</div>'+
      '</div></div>';
  }).join('');
}

/* ---------------- Quick view ---------------- */
let qv = { pid:null, size:null, color:null, qty:1 };
function openQV(pid){
  const p = findP(pid); if(!p) return;
  qv = { pid, size: SIZED_CATS.includes(p.cat)?SIZES[0]:null, color:p.colors?p.colors[0]:null, qty:1 };
  const pct = discountPct(p);
  let html = '<img src="'+p.img+'" alt="'+p.name+'"><div>'+
    '<h3 style="margin:0 0 6px">'+p.name+'</h3>'+
    '<div class="muted">'+CATS[p.cat]+(pct?' • <b style="color:#e63946">-'+pct+'% OFF</b>':'')+'</div>'+
    '<div style="margin:8px 0"><span class="price" style="font-size:22px">'+fmt(p.price)+'</span>'+(p.old?'<span class="old-price">'+fmt(p.old)+'</span>':'')+'</div>'+
    stars(p.rating)+
    '<p class="muted">'+p.desc+'</p>';
  if(qv.size){
    html += '<div class="opt-row"><b>Size:</b><div class="opt-btns" id="qvSizes">'+
      SIZES.map(s=>'<button data-s="'+s+'" class="'+(s===qv.size?'sel':'')+'">'+s+'</button>').join('')+'</div></div>';
  }
  if(p.colors){
    html += '<div class="opt-row"><b>Color:</b><div class="opt-btns" id="qvColors">'+
      p.colors.map(c=>'<button data-c="'+c+'" class="'+(c===qv.color?'sel':'')+'">'+c+'</button>').join('')+'</div></div>';
  }
  html += '<div class="opt-row"><b>Qty:</b><div class="qty-row">'+
    '<button id="qvMinus">−</button><span id="qvQty">1</span><button id="qvPlus">+</button></div></div>'+
    '<div class="card-actions"><button class="btn btn-buy" id="qvBuy">Buy — '+fmt(p.price)+'</button>'+
    '<button class="btn-wish'+(wishlist.has(p.id)?' active':'')+'" id="qvWish">❤️</button></div></div>';
  $('qvMain').innerHTML = html;

  // reviews
  $('qvReviews').innerHTML = '<h4>⭐ Reviews ('+p.reviews.length+')</h4>'+
    (p.reviews.map(r=>'<div class="review"><div class="r-head"><b>'+r.n+'</b>'+stars(r.r)+'</div><div>'+r.t+'</div></div>').join('') || '<p class="muted">এখনো review নেই — প্রথম review দিন!</p>')+
    '<form id="revForm" class="admin-form" style="margin-top:10px"><b>আপনার review দিন</b>'+
    '<label>নাম<input required id="revName"></label>'+
    '<label>Rating<select id="revRating"><option value="5">★★★★★ (5)</option><option value="4">★★★★ (4)</option><option value="3">★★★ (3)</option><option value="2">★★ (2)</option><option value="1">★ (1)</option></select></label>'+
    '<label>মতামত<textarea required id="revText" rows="2"></textarea></label>'+
    '<button class="btn btn-buy" type="submit">Submit Review</button>'+
    '<p class="tiny-note">Session-only ডেমো review।</p></form>';

  // related
  const rel = PRODUCTS.filter(x=>x.cat===p.cat && x.id!==p.id).slice(0,4);
  $('qvRelated').innerHTML = rel.length ? '<h4>এগুলোও দেখুন</h4><div class="related-grid">'+
    rel.map(r=>'<div class="rel" data-qv="'+r.id+'"><img src="'+r.img+'" alt="'+r.name+'"><div>'+r.name+'</div><div class="price">'+fmt(r.price)+'</div></div>').join('')+'</div>' : '';

  // wire events
  const sz = $('qvSizes'); if(sz) sz.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{
    qv.size=b.dataset.s; sz.querySelectorAll('button').forEach(x=>x.classList.toggle('sel',x===b));
  }));
  const cl = $('qvColors'); if(cl) cl.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{
    qv.color=b.dataset.c; cl.querySelectorAll('button').forEach(x=>x.classList.toggle('sel',x===b));
  }));
  $('qvMinus').addEventListener('click',()=>{ qv.qty=Math.max(1,qv.qty-1); $('qvQty').textContent=qv.qty; updQvBuy(p); });
  $('qvPlus').addEventListener('click',()=>{ qv.qty=Math.min(9,qv.qty+1); $('qvQty').textContent=qv.qty; updQvBuy(p); });
  $('qvBuy').addEventListener('click',()=>{ addToCart(qv.pid,qv.size,qv.color,qv.qty); closeModal('qvModal'); openCheckout(); });
  $('qvWish').addEventListener('click',()=>{ toggleWish(qv.pid); $('qvWish').classList.toggle('active', wishlist.has(qv.pid)); });
  $('revForm').addEventListener('submit',e=>{
    e.preventDefault();
    p.reviews.push({n:$('revName').value.trim(), r:+$('revRating').value, t:$('revText').value.trim()});
    toast('ধন্যবাদ! Review যোগ হয়েছে ⭐'); openQV(pid); renderProducts();
  });
  openModal('qvModal');
}
function updQvBuy(p){ $('qvBuy').textContent = 'Buy — '+fmt(p.price*qv.qty); }

/* ---------------- Wishlist ---------------- */
function toggleWish(pid){
  if(wishlist.has(pid)){ wishlist.delete(pid); toast('Wishlist থেকে সরানো হয়েছে'); }
  else { wishlist.add(pid); toast('❤️ Wishlist-এ যোগ হয়েছে'); }
  $('wishCount').textContent = wishlist.size;
  renderProducts(); renderWish();
}
function renderWish(){
  const list = [...wishlist].map(findP).filter(Boolean);
  $('wishBody').innerHTML = list.length ? list.map(p=>
    '<div class="cart-item"><img src="'+p.img+'" alt="'+p.name+'"><div class="ci-info"><b>'+p.name+'</b><div class="price">'+fmt(p.price)+'</div>'+
    '<button class="btn btn-buy" data-buy="'+p.id+'" style="margin-top:6px">Buy</button> '+
    '<button class="ci-remove" data-unwish="'+p.id+'">Remove</button></div></div>'
  ).join('') : '<p class="muted">Wishlist খালি। ❤️ বাটনে ক্লিক করে পছন্দের product save করুন।</p>';
}

/* ---------------- Cart ---------------- */
function cartKey(i){ return i.pid+'|'+(i.size||'')+'|'+(i.color||''); }
function addToCart(pid,size,color,qty){
  const k = cartKey({pid,size,color});
  const ex = cart.find(i=>cartKey(i)===k);
  if(ex) ex.qty = Math.min(9, ex.qty+qty); else cart.push({pid,size,color,qty});
  renderCart(); toast('🛒 Cart-এ যোগ হয়েছে');
}
function cartSubtotal(){ return cart.reduce((s,i)=>{ const p=findP(i.pid); return p?s+p.price*i.qty:s; },0); }
function renderCart(){
  cart = cart.filter(i=>findP(i.pid));
  const n = cart.reduce((s,i)=>s+i.qty,0);
  $('cartCount').textContent = n;
  $('cartBody').innerHTML = cart.length ? cart.map((i,idx)=>{
    const p = findP(i.pid);
    const meta = [i.size && ('Size: '+i.size), i.color && ('Color: '+i.color)].filter(Boolean).join(' • ');
    return '<div class="cart-item"><img src="'+p.img+'" alt="'+p.name+'"><div class="ci-info"><b>'+p.name+'</b>'+
      (meta?'<div class="muted">'+meta+'</div>':'')+
      '<div class="price">'+fmt(p.price*i.qty)+'</div>'+
      '<div class="qty-row"><button data-dec="'+idx+'">−</button><span>'+i.qty+'</span><button data-inc="'+idx+'">+</button></div>'+
      '<button class="ci-remove" data-rem="'+idx+'">Remove</button></div></div>';
  }).join('') : '<p class="muted">Cart খালি। Buy বাটনে ক্লিক করে shopping শুরু করুন! 🛍️</p>';
  $('cartFoot').innerHTML = cart.length ?
    '<div class="row"><span>Subtotal</span><span>'+fmt(cartSubtotal())+'</span></div>'+
    '<button class="btn btn-buy full" id="goCheckout">Checkout →</button>' : '';
  const g = $('goCheckout'); if(g) g.addEventListener('click',()=>{ closeDrawer('cartDrawer'); openCheckout(); });
}
function closeDrawer(id){ $(id).classList.remove('open'); $(id).setAttribute('aria-hidden','true'); }
function openDrawer(id){ $(id).classList.add('open'); $(id).setAttribute('aria-hidden','false'); }

/* ---------------- Checkout ---------------- */
function orderTotals(){
  const sub = cartSubtotal();
  const disc = coupon ? Math.round(sub * CONFIG.COUPONS[coupon]) : 0;
  const area = CONFIG.DELIVERY_AREAS.find(a=>a.id===$('coArea').value) || CONFIG.DELIVERY_AREAS[0];
  const charge = (sub - disc) >= CONFIG.FREE_DELIVERY_MIN ? 0 : area.charge;
  return { sub, disc, area, charge, total: sub - disc + charge };
}
function renderCheckoutSummary(){
  const t = orderTotals();
  $('coItems').innerHTML = cart.map(i=>{
    const p = findP(i.pid);
    const meta = [i.size, i.color].filter(Boolean).join(' / ');
    return '<div class="co-line"><span>'+p.name+(meta?' <span class="muted">('+meta+')</span>':'')+' × '+i.qty+'</span><span>'+fmt(p.price*i.qty)+'</span></div>';
  }).join('');
  $('coTotals').innerHTML =
    '<div class="co-line"><span>Subtotal</span><span>'+fmt(t.sub)+'</span></div>'+
    (t.disc?'<div class="co-line"><span>Coupon '+coupon+'</span><span>−'+fmt(t.disc)+'</span></div>':'')+
    '<div class="co-line"><span>Delivery ('+t.area.label+')</span><span>'+(t.charge===0?'FREE':fmt(t.charge))+'</span></div>'+
    '<div class="co-line grand"><span>Total</span><span>'+fmt(t.total)+'</span></div>';
}
function openCheckout(){
  if(!cart.length){ toast('Cart খালি — আগে product add করুন'); return; }
  coupon = null; $('coCoupon').value=''; $('couponMsg').textContent='';
  renderCheckoutSummary(); openModal('checkoutModal');
}
function buildWaMessage(o){
  const L = [];
  L.push('🛍️ *New Order — FashionGhor*');
  L.push('🧾 Order ID: '+o.id);
  L.push('');
  o.items.forEach((i,ix)=>{
    const meta = [i.size && ('Size: '+i.size), i.color && ('Color: '+i.color)].filter(Boolean).join(' | ');
    L.push((ix+1)+'. '+i.name+(meta?' ('+meta+')':''));
    L.push('   '+i.qty+' × '+fmt(i.price)+' = '+fmt(i.qty*i.price));
  });
  L.push('');
  L.push('Subtotal: '+fmt(o.subtotal));
  if(o.discount) L.push('Coupon ('+o.coupon+'): -'+fmt(o.discount));
  L.push('Delivery ('+o.areaLabel+'): '+(o.deliveryCharge===0?'FREE':fmt(o.deliveryCharge)));
  L.push('*Total: '+fmt(o.total)+'*');
  L.push('Payment: '+o.pay);
  L.push('');
  L.push('👤 '+o.name); L.push('📞 '+o.phone); L.push('📍 '+o.address);
  return L.join('\n');
}
function placeOrder(){
  const name=$('coName').value.trim(), phone=$('coPhone').value.trim(), addr=$('coAddress').value.trim();
  if(!name||!phone||!addr){ toast('নাম, মোবাইল ও ঠিকানা দিন'); return; }
  const t = orderTotals();
  const pay = document.querySelector('input[name="pay"]:checked').value;
  const id = 'FG-'+Math.random().toString(36).slice(2,8).toUpperCase();
  const o = {
    id, items: cart.map(i=>{ const p=findP(i.pid); return {name:p.name, price:p.price, qty:i.qty, size:i.size, color:i.color}; }),
    subtotal:t.sub, discount:t.disc, coupon, areaLabel:t.area.label, deliveryCharge:t.charge,
    total:t.total, pay: pay==='bKash (demo)' ? 'bKash (DEMO — unpaid)' : pay,
    name, phone, address:addr, status:'Received', date:new Date().toLocaleString('bn-BD')
  };
  orders.push(o);
  const url = 'https://wa.me/'+CONFIG.WHATSAPP_NUMBER+'?text='+encodeURIComponent(buildWaMessage(o));
  window.open(url,'_blank');
  cart = []; coupon=null; renderCart();
  closeModal('checkoutModal');
  renderInvoice(o);
  openModal('invoiceModal');
  toast('✅ Order তৈরি! WhatsApp-এ Send চাপুন');
}

/* ---------------- Invoice ---------------- */
function renderInvoice(o){
  $('invoiceBody').innerHTML = '<div class="invoice">'+
    '<div style="display:flex;align-items:center;gap:10px"><img src="assets/logo.png" style="height:44px" alt="logo"><div><h3 style="margin:0">FashionGhor</h3><div class="muted">Style delivered to your door</div></div></div>'+
    '<hr><div><b>Order ID:</b> '+o.id+'<br><b>Date:</b> '+o.date+'<br><b>Payment:</b> '+o.pay+'</div>'+
    '<table class="inv-table"><tr><th>Item</th><th>Qty</th><th style="text-align:right">Amount</th></tr>'+
    o.items.map(i=>'<tr><td>'+i.name+([i.size,i.color].filter(Boolean).join('/')?' <span class="muted">('+[i.size,i.color].filter(Boolean).join('/')+')</span>':'')+'</td><td>'+i.qty+'</td><td style="text-align:right">'+fmt(i.price*i.qty)+'</td></tr>').join('')+
    '</table>'+
    '<div class="co-line"><span>Subtotal</span><span>'+fmt(o.subtotal)+'</span></div>'+
    (o.discount?'<div class="co-line"><span>Coupon '+o.coupon+'</span><span>−'+fmt(o.discount)+'</span></div>':'')+
    '<div class="co-line"><span>Delivery ('+o.areaLabel+')</span><span>'+(o.deliveryCharge===0?'FREE':fmt(o.deliveryCharge))+'</span></div>'+
    '<div class="co-line grand"><span>Total</span><span>'+fmt(o.total)+'</span></div>'+
    '<hr><div><b>Customer:</b> '+o.name+'<br><b>Phone:</b> '+o.phone+'<br><b>Address:</b> '+o.address+'</div>'+
    '<p class="tiny-note">ডেমো invoice — session-only।</p></div>';
}

/* ---------------- Tracking ---------------- */
const STATUS_STEPS = ['Received','Packed','Shipped','Delivered'];
function trackOrder(){
  const id = $('trackInput').value.trim().toUpperCase();
  const o = orders.find(x=>x.id===id);
  if(!o){ $('trackResult').innerHTML = '<p class="err">Order ID পাওয়া যায়নি। এই session-এ করা order-ই track করা যাবে (ডেমো)।</p>'; return; }
  const si = STATUS_STEPS.indexOf(o.status);
  $('trackResult').innerHTML = '<div class="invoice" style="margin-top:12px"><b>'+o.id+'</b> — '+fmt(o.total)+
    '<div class="status-steps">'+STATUS_STEPS.map((s,i)=>'<span class="step'+(i<=si?' done':'')+'">'+(i<=si?'✅ ':'')+s+'</span>').join('')+'</div>'+
    '<p class="tiny-note">ডেমো status — admin panel থেকে status বদলানো যায়।</p></div>';
}

/* ---------------- Admin ---------------- */
function adminTab(name){
  document.querySelectorAll('#adminPanel .tabs [data-tab]').forEach(b=>b.classList.toggle('active', b.dataset.tab===name));
  ['products','add','orders','pw'].forEach(t=>$('tab-'+t).hidden = t!==name);
  if(name==='products') renderAdminProducts();
  if(name==='orders') renderAdminOrders();
}
function renderAdminProducts(){
  $('tab-products').innerHTML = '<table class="admin-table"><tr><th></th><th>Name</th><th>Price</th><th>Cat</th><th></th></tr>'+
    PRODUCTS.map(p=>'<tr><td><img src="'+p.img+'" alt=""></td><td>'+p.name+'</td><td>'+fmt(p.price)+'</td><td>'+CATS[p.cat]+'</td>'+
    '<td><button data-edit="'+p.id+'">Edit</button> <button class="del" data-del="'+p.id+'">Delete</button></td></tr>').join('')+'</table>';
}
function renderAdminOrders(){
  $('tab-orders').innerHTML = orders.length ? '<table class="admin-table"><tr><th>Order ID</th><th>Customer</th><th>Total</th><th>Status</th></tr>'+
    orders.map((o,ix)=>'<tr><td>'+o.id+'</td><td>'+o.name+'<br><span class="muted">'+o.phone+'</span></td><td>'+fmt(o.total)+'</td>'+
    '<td><select data-ostatus="'+ix+'">'+STATUS_STEPS.map(s=>'<option'+(s===o.status?' selected':'')+'>'+s+'</option>').join('')+'</select></td></tr>').join('')+'</table>'
    : '<p class="muted">এখনো কোনো order নেই (session-only)।</p>';
}
function resetAddForm(){
  $('addProductForm').reset(); $('apEditId').value=''; $('apPreview').hidden=true; $('apSubmit').textContent='Add Product';
}

/* ---------------- Wiring ---------------- */
document.addEventListener('DOMContentLoaded', ()=>{
  // hero
  renderSlides(); startHero();
  $('heroPrev').addEventListener('click',()=>goSlide(heroIdx-1));
  $('heroNext').addEventListener('click',()=>goSlide(heroIdx+1));
  // countdown
  tickCountdown(); setInterval(tickCountdown, 1000);
  // grid
  renderProducts(); renderCart(); renderWish();
  $('brandHome').addEventListener('click',e=>{e.preventDefault(); filter={cat:'all',q:''}; $('searchInput').value=''; syncNav(); renderProducts(); window.scrollTo({top:0,behavior:'smooth'});});
  // category nav
  document.querySelectorAll('#catNav [data-cat]').forEach(b=>b.addEventListener('click',()=>{
    filter.cat=b.dataset.cat; syncNav(); renderProducts();
  }));
  function syncNav(){ document.querySelectorAll('#catNav [data-cat]').forEach(b=>b.classList.toggle('active', b.dataset.cat===filter.cat)); }
  // search
  $('searchInput').addEventListener('input',e=>{ filter.q=e.target.value.trim(); renderProducts(); });
  // grid delegation
  $('productGrid').addEventListener('click',e=>{
    const qvT=e.target.closest('[data-qv]'); if(qvT){ openQV(+qvT.dataset.qv); return; }
    const buy=e.target.closest('[data-buy]'); if(buy){ const p=findP(+buy.dataset.buy); addToCart(p.id, SIZED_CATS.includes(p.cat)?SIZES[0]:null, p.colors?p.colors[0]:null, 1); return; }
    const w=e.target.closest('[data-wish]'); if(w){ toggleWish(+w.dataset.wish); }
  });
  if(!$('qvModal').dataset.relWired){
    $('qvModal').dataset.relWired='1';
    $('qvModal').addEventListener('click',e=>{
      const r=e.target.closest('[data-qv]');
      if(r && $('qvModal').classList.contains('open') && !$('qvMain').contains(r)) openQV(+r.dataset.qv);
    });
  }
  // drawers
  $('cartBtn').addEventListener('click',()=>{ renderCart(); openDrawer('cartDrawer'); });
  $('wishlistBtn').addEventListener('click',()=>{ renderWish(); openDrawer('wishDrawer'); });
  $('wishBody').addEventListener('click',e=>{
    const b=e.target.closest('[data-buy]'); if(b){ const p=findP(+b.dataset.buy); addToCart(p.id, SIZED_CATS.includes(p.cat)?SIZES[0]:null, p.colors?p.colors[0]:null, 1); return; }
    const u=e.target.closest('[data-unwish]'); if(u) toggleWish(+u.dataset.unwish);
  });
  $('cartBody').addEventListener('click',e=>{
    const inc=e.target.closest('[data-inc]'), dec=e.target.closest('[data-dec]'), rem=e.target.closest('[data-rem]');
    if(inc){ const i=cart[+inc.dataset.inc]; i.qty=Math.min(9,i.qty+1); renderCart(); renderCheckoutSummarySafe(); }
    if(dec){ const i=cart[+dec.dataset.dec]; i.qty--; if(i.qty<1) cart.splice(+dec.dataset.dec,1); renderCart(); renderCheckoutSummarySafe(); }
    if(rem){ cart.splice(+rem.dataset.rem,1); renderCart(); renderCheckoutSummarySafe(); }
  });
  function renderCheckoutSummarySafe(){ if($('checkoutModal').classList.contains('open')) renderCheckoutSummary(); }
  // checkout
  $('coArea').addEventListener('change',renderCheckoutSummary);
  document.querySelectorAll('input[name="pay"]').forEach(r=>r.addEventListener('change',()=>{
    $('bkashDemoNote').hidden = document.querySelector('input[name="pay"]:checked').value !== 'bKash (demo)';
  }));
  $('applyCoupon').addEventListener('click',()=>{
    const code=$('coCoupon').value.trim().toUpperCase();
    if(CONFIG.COUPONS[code]){ coupon=code; $('couponMsg').textContent='✅ Coupon applied: '+(CONFIG.COUPONS[code]*100)+'% off'; $('couponMsg').style.color='green'; }
    else { coupon=null; $('couponMsg').textContent='❌ ভুল coupon code'; $('couponMsg').style.color='red'; }
    renderCheckoutSummary();
  });
  $('waOrderBtn').addEventListener('click',placeOrder);
  $('checkoutForm').addEventListener('submit',e=>e.preventDefault());
  $('printInvoice').addEventListener('click',()=>window.print());
  // tracking
  $('trackBtn').addEventListener('click',trackOrder);
  $('navTrack').addEventListener('click',()=>{ $('trackSection').scrollIntoView({behavior:'smooth'}); });
  // admin
  const openAdmin=()=>{ $('adminGate').hidden=false; $('adminPanel').hidden=true; $('adminErr').textContent=''; $('adminPass').value=''; openModal('adminModal'); };
  $('navAdmin').addEventListener('click',openAdmin);
  $('navAddProduct').addEventListener('click',openAdmin);
  $('adminLoginBtn').addEventListener('click',()=>{
    if($('adminPass').value===adminPassword){
      $('adminGate').hidden=true; $('adminPanel').hidden=false; adminTab('products'); resetAddForm();
    } else $('adminErr').textContent='ভুল password!';
  });
  $('adminLogout').addEventListener('click',openAdmin);
  document.querySelectorAll('#adminPanel .tabs [data-tab]').forEach(b=>b.addEventListener('click',()=>adminTab(b.dataset.tab)));
  $('tab-products').addEventListener('click',e=>{
    const ed=e.target.closest('[data-edit]'), del=e.target.closest('[data-del]');
    if(ed){
      const p=findP(+ed.dataset.edit);
      $('apEditId').value=p.id; $('apName').value=p.name; $('apPrice').value=p.price; $('apOldPrice').value=p.old||'';
      $('apCat').value=p.cat; $('apDesc').value=p.desc||'';
      $('apPreview').src=p.img; $('apPreview').hidden=false;
      $('apSubmit').textContent='Save Changes'; adminTab('add');
    }
    if(del){
      if(confirm('Product delete করবেন?')){
        const ix=PRODUCTS.findIndex(p=>p.id===+del.dataset.del);
        if(ix>-1) PRODUCTS.splice(ix,1);
        wishlist.delete(+del.dataset.del); renderProducts(); renderAdminProducts(); toast('Product deleted');
      }
    }
  });
  let apImgData = '';
  $('apImage').addEventListener('change',e=>{
    const f=e.target.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=ev=>{ apImgData=ev.target.result; $('apPreview').src=apImgData; $('apPreview').hidden=false; };
    r.readAsDataURL(f);
  });
  $('addProductForm').addEventListener('submit',e=>{
    e.preventDefault();
    const editId=+$('apEditId').value;
    const data={
      name:$('apName').value.trim(), price:+$('apPrice').value, old:+$('apOldPrice').value||0,
      cat:$('apCat').value, desc:$('apDesc').value.trim(),
      img: apImgData || 'assets/prod-01.png', rating:5, colors:null, reviews:[]
    };
    if(editId){
      const p=findP(editId); const keepImg=p.img;
      Object.assign(p,data);
      if(!apImgData) p.img=keepImg; // keep old image when no new upload
      toast('✅ Product updated');
    } else {
      data.id = Math.max(...PRODUCTS.map(p=>p.id))+1;
      PRODUCTS.push(data); toast('✅ Product added!');
    }
    apImgData=''; resetAddForm(); renderProducts(); adminTab('products');
  });
  $('tab-orders').addEventListener('change',e=>{
    const s=e.target.closest('[data-ostatus]');
    if(s){ orders[+s.dataset.ostatus].status=s.value; toast('Status: '+s.value); }
  });
  $('pwForm').addEventListener('submit',e=>{
    e.preventDefault(); $('pwErr').textContent=''; $('pwOk').textContent='';
    if($('pwOld').value!==adminPassword){ $('pwErr').textContent='পুরনো password ভুল!'; return; }
    adminPassword=$('pwNew').value; $('pwOk').textContent='✅ Password changed (এই session-এর জন্য)';
    $('pwForm').reset(); toast('🔐 Password changed');
  });
});
